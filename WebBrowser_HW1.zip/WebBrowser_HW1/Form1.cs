﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebBrowser_HW1
{
    
    public partial class Form1 : Form
    {
        ServiceReferenceStockQuote.ServiceClient stockRef = new ServiceReferenceStockQuote.ServiceClient();
        ServiceReferenceEncryptDecrypt.ServiceClient cryptRef = new ServiceReferenceEncryptDecrypt.ServiceClient();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DisplayStock.Text = stockRef.getStockquote(StockSymbol.Text);
        }

        private void Encrypt_Click(object sender, EventArgs e)
        {
            StringToCrypt.Text = cryptRef.Encrypt(StringToCrypt.Text);
        }

        private void Decrypt_Click(object sender, EventArgs e)
        {   
            try
            { StringToCrypt.Text = cryptRef.Decrypt(StringToCrypt.Text); }
            catch(Exception)
            { }
        }
    }
}
